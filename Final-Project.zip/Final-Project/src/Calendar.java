import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.GregorianCalendar;

public class Calendar { // CLASS FOR CALENDAR FRAME
    JFrame calendarFrame = new JFrame();
    JPanel calendarPanel = new JPanel();
    // CALENDAR HEADER //
    JPanel calendarHeader = new JPanel();
    JButton toDashboardButton = new JButton("Dashboard");
    JButton toTaskListButton = new JButton("Task List");
    JButton toCalendarButton = new JButton("Calendar");
    JButton toAddButton = new JButton("Add New");
    // CALENDAR //
    static DefaultTableModel calendar;
    static JButton next, prev, today;
    static JComboBox cmbyear;
    static JLabel month, year;
    static JTable table;
    static JScrollPane s1;
    static int realYear, realMonth, realDay, currentYear, currentMonth;
    JPanel mainPanel = new JPanel(); // Grid layout //
    Calendar() {
        calendarPanel.setLayout(new GridBagLayout());

        // HEADER //

        calendarHeader.setLayout(new FlowLayout());
        calendarHeader.setBackground(Color.yellow);
        ((FlowLayout)calendarHeader.getLayout()).setHgap(50);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.ipady = 100;
        c.ipadx = 600;
        calendarPanel.add(calendarHeader, c);

            // add COMPONENTS to HEADER //

        JPanel dashboardButton = new JPanel();
        dashboardButton.setBackground(Color.yellow);
        dashboardButton.setPreferredSize(new Dimension(150,70));
        toDashboardButton.setPreferredSize(new Dimension(150, 50));
        toDashboardButton.setBackground(Color.white);
        dashboardButton.add(toDashboardButton);
        JPanel taskListButton = new JPanel();
        taskListButton.setBackground(Color.yellow);
        taskListButton.setPreferredSize(new Dimension(150,70));
        toTaskListButton.setPreferredSize(new Dimension(150, 50));
        toTaskListButton.setBackground(Color.white);
        taskListButton.add(toTaskListButton);
        JPanel calendarButton = new JPanel();
        calendarButton.setBackground(Color.yellow);
        calendarButton.setPreferredSize(new Dimension(150,70));
        toCalendarButton.setPreferredSize(new Dimension(150, 50));
        toCalendarButton.setBackground(Color.white);
        calendarButton.add(toCalendarButton);
        JPanel addButton = new JPanel();
        addButton.setBackground(Color.yellow);
        addButton.setPreferredSize(new Dimension(150,70));
        toAddButton.setPreferredSize(new Dimension(150, 50));
        toAddButton.setBackground(Color.white);
        addButton.add(toAddButton);
        calendarHeader.add(dashboardButton);
        calendarHeader.add(taskListButton);
        calendarHeader.add(calendarButton);
        calendarHeader.add(addButton);

        // Main Panel //
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(200,200,200));
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        c.ipady = 700;
        calendarPanel.add(mainPanel, c);

        //
        next = new JButton("Next");
        next.setToolTipText("Go forward a month");
        prev = new JButton("Prev");
        prev.setToolTipText("Go back a month");
        today = new JButton("Today");
        today.setToolTipText("Current Date");
        cmbyear = new JComboBox();
        cmbyear.setToolTipText("Change year");
        month = new JLabel("January");
        month.setToolTipText("Current month");
        month.setFont(new Font("Arial", Font.BOLD, 20));
        year = new JLabel("Change year:");
        year.setFont(new Font("Arial", Font.BOLD, 20));
        calendar = new DefaultTableModel()
        {
            public boolean isCellEditable(int rowIndex, int mColIndex)
            {
                return false;
            }
        };
        table = new JTable(calendar);
        table.setFont(new Font("Arial", Font.BOLD, 15));
        table.setBackground(Color.LIGHT_GRAY);
        s1 = new JScrollPane(table);
        //        Register action listner       //
        next.addActionListener(new next_Action());
        prev.addActionListener(new prev_Action());
        today.addActionListener(new today_action());
        cmbyear.addActionListener(new cmyear_Action());

        //          Add to controls         //
        mainPanel.add(next);
        mainPanel.add(today);
        mainPanel.add(cmbyear);
        mainPanel.add(prev);
        mainPanel.add(month);
        mainPanel.add(year);
        mainPanel.add(s1);

        //        Set Bounds              //
        cmbyear.setBounds(1000, 570, 100, 30);
        prev.setBounds(10, 20, 65, 35);
        next.setBounds(90, 20, 65, 35);
        today.setBounds(1160, 20, 85, 35);
        month.setBounds(220 - month.getPreferredSize().width / 2, 25, 150, 25);
        year.setBounds(10, 490, 180, 200);
        s1.setBounds(10, 55, 1250, 480);
        // GREGORIAN CALENDAR //
        GregorianCalendar cal = new GregorianCalendar();
        realDay = cal.get(GregorianCalendar.DAY_OF_MONTH);
        realMonth = cal.get(GregorianCalendar.MONTH);
        realYear = cal.get(GregorianCalendar.YEAR);
        currentMonth = realMonth;
        currentYear = realYear;
        // Add headers //
        String[] headers = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
        for (int i = 0; i < 7; i++)
        {
            calendar.addColumn(headers[i]);
        }
        // 				No resize/reorder	  		 //
        table.getTableHeader().setResizingAllowed(false);
        table.getTableHeader().setReorderingAllowed(false);

        // 			Single cell selection		//
        table.setColumnSelectionAllowed(true);
        table.setRowSelectionAllowed(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // 			Set row/column count			//
        table.setRowHeight(66);
        calendar.setColumnCount(7);
        calendar.setRowCount(6);
        // 		Combo box of year		 //
        for (int i = realYear - 100; i <= realYear + 100; i++)
        {
            cmbyear.addItem(String.valueOf(i));
        }

        // Refresh calendar //

        refreshCalendar(realMonth, realYear);

        //

        calendarFrame.add(calendarPanel);
        calendarFrame.setResizable(false);
        calendarFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // SET FULLSCREEN //
        calendarFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }


    private static void refreshCalendar(int rmonth, int ryear)
    {
        String[] months = { "January", "February", "March",
                "April", "May", "June", "July", "August",
                "September","October", "November", "December" };
        int nod, som;	// Number Of Days, Start Of Month
        prev.setEnabled(true);
        next.setEnabled(true);
        today.setEnabled(true);
        if (rmonth == 0 && ryear <= realYear - 10) {
            prev.setEnabled(false);
        }
        if (rmonth == 11 && ryear >= realYear + 100) {
            next.setEnabled(false);
        }
        if (rmonth == realMonth && ryear == realYear) {
            today.setEnabled(false);
        }
        month.setText(months[rmonth]);
        month.setBounds(220 - month.getPreferredSize().width / 2, 25, 150, 25);
        cmbyear.setSelectedItem(String.valueOf(ryear));

        // 			Clear table				//
        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 7; j++)
            {
                calendar.setValueAt(null, i, j);
            }
        }

        //		 Get first day of month and number of days		//
        GregorianCalendar cal = new GregorianCalendar(ryear, rmonth, 1);
        nod = cal.getActualMaximum(GregorianCalendar.DAY_OF_MONTH);
        som = cal.get(GregorianCalendar.DAY_OF_WEEK);

        //		 Draw calendar			//
        for (int i = 1; i <= nod; i++)
        {
            int row = (int )((i + som - 2) / 7);
            int column = (i + som - 2) % 7;
            calendar.setValueAt(i, row, column);
        }
        // 			Apply renderers			//
        table.setDefaultRenderer(table.getColumnClass(0), new tblCalendarRenderer());
    }
    static class tblCalendarRenderer extends DefaultTableCellRenderer
    {
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean selected, boolean focused,int row, int column)
        {
            super.getTableCellRendererComponent(table, value, selected, focused, row, column);
            if (column == 0 || column == 6)
            { // Weekend
                setBackground(new Color(0, 204, 255));
            }
            else
            { // Week
                setBackground(new Color(255, 255, 153));
            }
            if (value != null)
            {
                if (Integer.parseInt(value.toString()) == realDay &&
                        currentMonth == realMonth && currentYear == realYear)
                { // Today
                    setBackground(new Color(220, 220, 255));
                }
            }
            setBorder(null);
            setForeground(Color.black);
            return this;
        }
    }
    static class prev_Action implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if (currentMonth == 0)
            {
                //  	Back one year		//
                currentMonth = 11;
                currentYear -= 1;
            }
            else
            {
                //	 Back one month		//
                currentMonth -= 1;
            }
            refreshCalendar(currentMonth, currentYear);
        }
    }

    static class next_Action implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if (currentMonth == 11)
            { // Foward one year
                currentMonth = 0;
                currentYear += 1;
            }
            else
            { // Foward one month
                currentMonth += 1;
            }
            refreshCalendar(currentMonth, currentYear);
        }
    }

    static class cmyear_Action implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if (cmbyear.getSelectedItem() != null) {
                String b = cmbyear.getSelectedItem().toString();
                currentYear = Integer.parseInt(b);
                refreshCalendar(currentMonth, currentYear);
            }
        }
    }

    static class today_action extends DefaultTableCellRenderer implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            currentMonth = realMonth;
            currentYear = realYear;
            refreshCalendar(currentMonth, currentYear);
        }

    }
}
