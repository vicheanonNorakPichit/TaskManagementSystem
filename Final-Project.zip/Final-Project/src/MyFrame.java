import javax.swing.*;
import java.awt.*;

public class MyFrame {
    static Dashboard dashboard = new Dashboard();
    static Calendar calendar = new Calendar();
    static TaskList taskList = new TaskList();
    static AddTaskFrame addTask = new AddTaskFrame();
    MyFrame() {
        Task.addToList(Main.tasks);

        // FRAME //
        dashboard.dashboardFrame.setVisible(true);
        calendar.calendarFrame.setVisible(false);
        taskList.taskListFrame.setVisible(false);

        // add ACTION to HEADER BUTTON //
        dashboard.toCalendarButton.addActionListener(e -> {
            switchToCalendar();
        });
        dashboard.toTaskListButton.addActionListener(e -> {
            switchToTaskList();
        });
        dashboard.toAddButton.addActionListener(e -> {
            addTask();
        });
        calendar.toDashboardButton.addActionListener(e -> {
            switchToDashboard();
        });
        calendar.toTaskListButton.addActionListener(e -> {
            switchToTaskList();
        });
        calendar.toAddButton.addActionListener(e -> {
            addTask();
        });
        taskList.toDashboardButton.addActionListener(e -> {
            switchToDashboard();
        });
        taskList.toCalendarButton.addActionListener(e -> {
            switchToCalendar();
        });
        taskList.toAddButton.addActionListener(e -> {
            addTask();
        });
    }

    // Method for switching frame //
    static void switchToDashboard() {
        calendar.calendarFrame.setVisible(false);
        taskList.taskListFrame.setVisible(false);
        dashboard.dashboardFrame.setVisible(true);
    }
    static void switchToTaskList() {
        calendar.calendarFrame.setVisible(false);
        taskList.taskListFrame.setVisible(true);
        dashboard.dashboardFrame.setVisible(false);
    }
    static void switchToCalendar() {
        calendar.calendarFrame.setVisible(true);
        taskList.taskListFrame.setVisible(false);
        dashboard.dashboardFrame.setVisible(false);
    }
    static void addTask() {
        addTask.frame.setVisible(true);
    }
    void addToList(Task newTask) {
        JPanel taskPane = new JPanel();
        taskPane.setBackground(Dashboard.getColor(newTask));
        JLabel taskName = new JLabel(newTask.getName());
        taskName.setForeground(Color.white);
        JButton complete = new JButton("Complete" );
        complete.addActionListener(e -> {
            MyFrame.taskList.completePanel.add(taskPane);
            taskPane.remove(complete);
            MyFrame.taskList.toDoPanel.revalidate();
            MyFrame.taskList.toDoPanel.repaint();
            MyFrame.taskList.completePanel.revalidate();
            MyFrame.taskList.completePanel.repaint();
        });
        complete.setSize(20,20);
        complete.setPreferredSize(new Dimension(95,20));
        complete.setBackground(Color.green);
        JButton delete = new JButton("Delete" );
        delete.addActionListener(e -> {
            MyFrame.taskList.toDoPanel.remove(taskPane);
            MyFrame.taskList.completePanel.remove(taskPane);
            MyFrame.taskList.toDoPanel.revalidate();
            MyFrame.taskList.toDoPanel.repaint();
            MyFrame.taskList.completePanel.revalidate();
            MyFrame.taskList.completePanel.repaint();
        });
        delete.setSize(30,20);
        delete.setPreferredSize(new Dimension(75,20));

        taskPane.add(taskName);
        taskPane.add(delete);
        taskPane.add(complete);
        MyFrame.taskList.toDoPanel.add(taskPane);
    }
}
