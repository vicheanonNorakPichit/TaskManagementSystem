import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.Objects;
import java.util.Scanner;

public class TaskList { // CLASS FOR TASK LIST FRAME
    JFrame taskListFrame = new JFrame();
    JPanel taskListPanel = new JPanel();
    JPanel taskListHeader = new JPanel();
    JPanel taskListMain = new JPanel();
    JPanel toDoPanel = new JPanel();
    JPanel completePanel = new JPanel();
    JPanel noDeadlinePanel = new JPanel();
    JButton toDashboardButton = new JButton("Dashboard");
    JButton toTaskListButton = new JButton("Task List");
    JButton toCalendarButton = new JButton("Calendar");
    JButton toAddButton = new JButton("Add New");

    TaskList() {
        taskListPanel.setLayout(new GridBagLayout());

        // HEADER //

        taskListHeader.setLayout(new FlowLayout());
        taskListHeader.setBackground(Color.yellow);
        ((FlowLayout) taskListHeader.getLayout()).setHgap(50);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.ipady = 450;
        c.ipadx = 600;
        taskListPanel.add(taskListHeader, c);

        // add COMPONENTS to HEADER //

        JPanel dashboardButton = new JPanel();
        dashboardButton.setBackground(Color.yellow);
        dashboardButton.setPreferredSize(new Dimension(150,70));
        toDashboardButton.setPreferredSize(new Dimension(150, 50));
        toDashboardButton.setBackground(Color.white);
        dashboardButton.add(toDashboardButton);
        JPanel taskListButton = new JPanel();
        taskListButton.setBackground(Color.yellow);
        taskListButton.setPreferredSize(new Dimension(150,70));
        toTaskListButton.setPreferredSize(new Dimension(150, 50));
        toTaskListButton.setBackground(Color.white);
        taskListButton.add(toTaskListButton);
        JPanel calendarButton = new JPanel();
        calendarButton.setBackground(Color.yellow);
        calendarButton.setPreferredSize(new Dimension(150,70));
        toCalendarButton.setPreferredSize(new Dimension(150, 50));
        toCalendarButton.setBackground(Color.white);
        calendarButton.add(toCalendarButton);
        JPanel addButton = new JPanel();
        addButton.setBackground(Color.yellow);
        addButton.setPreferredSize(new Dimension(150,70));
        toAddButton.setPreferredSize(new Dimension(150, 50));
        toAddButton.setBackground(Color.white);
        addButton.add(toAddButton);
        taskListHeader.add(dashboardButton);
        taskListHeader.add(taskListButton);
        taskListHeader.add(calendarButton);
        taskListHeader.add(addButton);

        // Main Panel //
        taskListMain.setLayout(new FlowLayout());
        ((FlowLayout)taskListMain.getLayout()).setHgap(150);
        taskListMain.setBackground(Color.gray);
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        c.ipady = 500;
        taskListPanel.add(taskListMain, c);


        // To do //
        toDoPanel.setLayout(new GridLayout(15,1));
        toDoPanel.setPreferredSize(new Dimension(450, 600));
        toDoPanel.setBackground(Color.white);
        taskListMain.add(toDoPanel);
        JPanel toDo = new JPanel();
        toDo.setBackground(new Color(0, 204, 255));
        toDo.add(new JLabel("TO DO LIST"));
        toDoPanel.add(toDo);
        for (Task task: Main.tasks) {
            if (Objects.equals(task.getState(), "toDo")) {
                JPanel taskPane = new JPanel();
                taskPane.setBackground(Dashboard.getColor(task));
                JLabel taskName = new JLabel(task.getName());
                taskName.setForeground(Color.white);
                JButton complete = new JButton("Complete" );
                complete.addActionListener(e -> {
                    completePanel.add(taskPane);
                    taskPane.remove(complete);
                    toDoPanel.revalidate();
                    toDoPanel.repaint();
                    completePanel.revalidate();
                    completePanel.repaint();
                });
                complete.setSize(20,20);
                complete.setPreferredSize(new Dimension(95,20));
                complete.setBackground(Color.green);
                JButton delete = new JButton("Delete" );
                delete.addActionListener(e -> {
                    toDoPanel.remove(taskPane);
                    completePanel.remove(taskPane);
                    toDoPanel.revalidate();
                    toDoPanel.repaint();
                    completePanel.revalidate();
                    completePanel.repaint();
                });
                delete.setSize(30,20);
                delete.setPreferredSize(new Dimension(75,20));

                taskPane.add(taskName);
                taskPane.add(delete);
                taskPane.add(complete);
                toDoPanel.add(taskPane);
            }
        }
        // Complete //
        completePanel.setLayout(new GridLayout(15,1));
        completePanel.setPreferredSize(new Dimension(450, 600));
        completePanel.setBackground(Color.white);
        taskListMain.add(completePanel);
        JPanel complete = new JPanel();
        complete.setBackground(new Color(0, 204, 255));
        complete.add(new JLabel("COMPLETE LIST"));
        completePanel.add(complete);
        for (Task task: Main.tasks) {
            if (Objects.equals(task.getState(), "Complete")) {
                JPanel taskPane = new JPanel();
                taskPane.setBackground(Dashboard.getColor(task));
                JLabel taskName = new JLabel(task.getName());
                taskName.setForeground(Color.white);
                JButton delete = new JButton("Delete" );
                delete.addActionListener(e -> {
                    completePanel.remove(taskPane);
                });
                delete.setSize(30,20);
                delete.setPreferredSize(new Dimension(75,20));

                taskPane.add(taskName);
                taskPane.add(delete);
                taskPane.add(complete);
                toDoPanel.add(taskPane);
            }
        }

        taskListFrame.add(taskListPanel);
        taskListFrame.setResizable(false);
        taskListFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // SET FULLSCREEN //
        taskListFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
}
