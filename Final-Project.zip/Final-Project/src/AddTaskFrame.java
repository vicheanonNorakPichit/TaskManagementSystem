import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.Exception;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

class AddTaskFrame extends JFrame implements ActionListener {
    JFrame frame;
    JPanel headerPanel,formPanel,taskNamePanel,descriptionPanel,deadlinePanel,priorityPanel,buttonPanel;
    JLabel headerLabel, taskNameLabel,descriptionLabel,deadlineLabel,priorityLabel;
    JTextField  taskNameField, descriptionField, deadlineField;
    JCheckBox priorityA, priorityB, priorityC, priorityD;
    JButton cancelButton,addTaskButton;
    JComboBox date,month,year;
    String dates[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
            "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
            "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };
    String months[] = { "Jan", "feb", "Mar", "Apr",
            "May", "Jun", "July", "Aug",
            "Sup", "Oct", "Nov", "Dec" };
    String years[] = {"2023","2024","2025","2026","2027","2028","2029","2030"};

    AddTaskFrame() {
        frame = new JFrame();

        frame.setSize(500,390);
        frame.setPreferredSize(new Dimension(500,400));
        frame.setLayout(null);
        frame.setDefaultCloseOperation(HIDE_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);


        //HEADER PANEL
        headerPanel = new JPanel();
        headerPanel.setBounds(0,0,500,35);
        headerPanel.setBackground(Color.YELLOW);
        frame.add(headerPanel);

        headerLabel = new JLabel("Add New Task");
        headerLabel.setFont(new Font("Time New Roman", Font.BOLD, 16));
        headerPanel.add(headerLabel);

        //FORM PANEL
        formPanel = new JPanel(new GridLayout(5,1));
        formPanel.setBounds(15,50,455,290);
        formPanel.setBackground(Color.gray);
        frame.add(formPanel);

        //FORM PANEL / Task Name Panel
        taskNamePanel = new JPanel();
        taskNamePanel.setBackground(Color.lightGray);
        taskNamePanel.setLayout(null);
        formPanel.add(taskNamePanel);

        taskNameLabel = new JLabel("Task name: ");
        taskNameLabel.setBounds(10,10,300,40);
        taskNamePanel.add(taskNameLabel);

        taskNameField = new JTextField();
        taskNameField.setColumns(30);
        taskNameField.setBounds(100,10,300,40);
        taskNamePanel.add(taskNameField);


        //FORM PANEL / Description Panel
        descriptionPanel = new JPanel();
        descriptionPanel.setBackground(Color.lightGray);
        descriptionPanel.setLayout(null);
        formPanel.add(descriptionPanel);

        descriptionLabel = new JLabel("Description: ");
        descriptionLabel.setBounds(10,10,300,40);
        descriptionPanel.add(descriptionLabel);

        descriptionField = new JTextField();
        descriptionField.setColumns(30);
        descriptionField.setBounds(100,10,300,40);
        descriptionPanel.add(descriptionField);

        //FORM PANEL / Deadline Panel
        deadlinePanel = new JPanel();
        deadlinePanel.setBackground(Color.lightGray);
        deadlinePanel.setLayout(null);
        formPanel.add(deadlinePanel);

        deadlineLabel = new JLabel("Deadline: ");
        deadlineLabel.setBounds(10,10,300,40);
        deadlinePanel.add(deadlineLabel);

        date = new JComboBox<>(dates);
        date.setBounds(100,20,40,25);
        deadlinePanel.add(date);

        month = new JComboBox<>(months);
        month.setBounds(160,20,80,25);
        deadlinePanel.add(month);

        year = new JComboBox<>(years);
        year.setBounds(260,20,80,25);
        deadlinePanel.add(year);


        //FORM PANEL / Priority Panel
        priorityPanel = new JPanel();
        priorityPanel.setBackground(Color.lightGray);
        priorityPanel.setLayout(null);
        formPanel.add(priorityPanel);

        priorityLabel = new JLabel("Priority: ");
        priorityLabel.setBounds(10,10,300,40);
        priorityPanel.add(priorityLabel);

        priorityA = new JCheckBox("A");
        priorityA.setBounds(100,10, 50,40);
        priorityA.setBackground(Color.lightGray);
        priorityPanel.add(priorityA);

        priorityB = new JCheckBox("B");
        priorityB.setBounds(150,10, 50,40);
        priorityB.setBackground(Color.lightGray);
        priorityPanel.add(priorityB);

        priorityC = new JCheckBox("C");
        priorityC.setBounds(200,10, 50,40);
        priorityC.setBackground(Color.lightGray);
        priorityPanel.add(priorityC);

        priorityD = new JCheckBox("D");
        priorityD.setBounds(250,10, 50,40);
        priorityD.setBackground(Color.lightGray);
        priorityPanel.add(priorityD);

        priorityA.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                priorityB.setSelected(false);
                priorityC.setSelected(false);
                priorityD.setSelected(false);
            }
        });
        priorityB.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                priorityA.setSelected(false);
                priorityC.setSelected(false);
                priorityD.setSelected(false);
            }
        });
        priorityC.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                priorityA.setSelected(false);
                priorityB.setSelected(false);
                priorityD.setSelected(false);
            }
        });
        priorityD.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                priorityA.setSelected(false);
                priorityB.setSelected(false);
                priorityC.setSelected(false);
            }
        });

        //FORM PANEL /Button Panel
        buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.gray);
        buttonPanel.setLayout(null);
        formPanel.add(buttonPanel);

        cancelButton = new JButton("Cancel");
        cancelButton.setBounds(10,10,100,40);
        cancelButton.setBackground(Color.lightGray);
        buttonPanel.add(cancelButton);

        addTaskButton = new JButton("Add Task");
        addTaskButton.setBounds(345,10,100,40);
        addTaskButton.setBackground(Color.yellow);
        addTaskButton.addActionListener(this::actionPerformed);
        buttonPanel.add(addTaskButton);


        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        try {
            String name = taskNameField.getText();
            String description = descriptionField.getText();
            char priority = 'X';
            if (priorityA.isSelected() ==true){
                priority = 'A';
            }else if (priorityB.isSelected() ==true){
                priority = 'B';
            }
            else if (priorityC.isSelected() ==true){
                priority = 'C';
            }
            else {
                priority = 'D';
            }

            String deadline = date.getSelectedItem() + " " + month.getSelectedItem() + " " +  year.getSelectedItem();
            FileWriter writer = new FileWriter("addnewtask.txt", true);
            BufferedWriter buffer = new BufferedWriter(writer);
            buffer.append(name + "/" + description + "/" + priority + "/" + deadline + "/" + this.getState() + "\n");
            buffer.close();
            Task newTask = new Task(name, description, priority, deadline, "asdds");
            Main.run.addToList(newTask);
            JPanel newCard = new JPanel();
            newCard.setLayout(new BorderLayout());
            newCard.setPreferredSize(new Dimension(210, 225));
            newCard.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            JPanel realDeadline = new JPanel();
            realDeadline.setPreferredSize(new Dimension(190, 20));
            JLabel newDate = new JLabel();
            DateFormat dateFormat = new SimpleDateFormat("EEE dd MMM yyyy");
            String dateText = dateFormat.format(newTask.getDeadline());
            newDate.setText(dateText);
            Date current = new Date();
            long remain = newTask.getDeadline().getTime() - current.getTime();
            JLabel remaining = new JLabel(MyFrame.dashboard.milliToDays(remain));
            realDeadline.add(newDate);
            realDeadline.add(remaining);
            newCard.add(realDeadline, BorderLayout.NORTH);
            JPanel descPane = new JPanel();
            descPane.setPreferredSize(new Dimension(140, 185));
            JLabel title = new JLabel("Description:");
            JTextArea desc = new JTextArea();
            desc.setLineWrap(true);
            desc.setWrapStyleWord(true);
            desc.setOpaque(false);
            desc.setEditable(false);
            desc.setText(newTask.getDescription());
            descPane.add(title);
            descPane.add(desc);
            newCard.add(descPane, BorderLayout.CENTER);
            // ADD NAME LABEL //
            JPanel namePane = new JPanel();
            namePane.setBackground(MyFrame.dashboard.getColor(newTask));
            JLabel newName = new JLabel();
            newName.setForeground(Color.white);
            newName.setText(newTask.getName());
            namePane.add(newName);
            namePane.setPreferredSize(new Dimension(150,30));
            newCard.add(namePane, BorderLayout.SOUTH);
            MyFrame.dashboard.cardPanel.add(newCard);
            MyFrame.taskList.taskListFrame.revalidate();
            MyFrame.taskList.taskListFrame.repaint();
            MyFrame.dashboard.dashboardFrame.revalidate();
            MyFrame.dashboard.dashboardFrame.repaint();
            //String name, String description, char priority, String deadline, String word
        } catch (IOException | ParseException e) {
            System.out.println("Error occurred!");
        }
        frame.setVisible(false);



    }

}
