import javax.swing.*;
import java.awt.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

public class Dashboard { //CLASS FOR DASHBOARD FRAME
    JFrame dashboardFrame = new JFrame();
    // HEADER DECLARATION //
    JPanel dashboardPanel = new JPanel();
    // HEADER //
    JPanel dashboardHeader = new JPanel();
    JButton toDashboardButton = new JButton("Dashboard");
    JButton toTaskListButton = new JButton("Task List");
    JButton toCalendarButton = new JButton("Calendar");
    JButton toAddButton = new JButton("Add new task");
    ArrayList<JPanel> cardPanelList = new ArrayList<JPanel>();
    // CALENDAR IN DASHBOARD //
    JPanel calendarPanel = new JPanel();
    JPanel cardPanel = new JPanel();
    JPanel bottomPanel = new JPanel();
    Dashboard() {

        dashboardPanel.setLayout(new GridBagLayout());
        // add COMPONENTS to HEADER //

        JPanel dashboardButton = new JPanel();
        dashboardButton.setBackground(Color.yellow);
        dashboardButton.setPreferredSize(new Dimension(150,70));
        toDashboardButton.setPreferredSize(new Dimension(150, 50));
        toDashboardButton.setBackground(Color.white);
        dashboardButton.add(toDashboardButton);
        JPanel taskListButton = new JPanel();
        taskListButton.setBackground(Color.yellow);
        taskListButton.setPreferredSize(new Dimension(150,70));
        toTaskListButton.setPreferredSize(new Dimension(150, 50));
        toTaskListButton.setBackground(Color.white);
        taskListButton.add(toTaskListButton);
        JPanel calendarButton = new JPanel();
        calendarButton.setBackground(Color.yellow);
        calendarButton.setPreferredSize(new Dimension(150,70));
        toCalendarButton.setPreferredSize(new Dimension(150, 50));
        toCalendarButton.setBackground(Color.white);
        calendarButton.add(toCalendarButton);
        JPanel addButton = new JPanel();
        addButton.setBackground(Color.yellow);
        addButton.setPreferredSize(new Dimension(150,70));
        toAddButton.setPreferredSize(new Dimension(150, 50));
        toAddButton.setBackground(Color.white);
        addButton.add(toAddButton);
        dashboardHeader.add(dashboardButton);
        dashboardHeader.add(taskListButton);
        dashboardHeader.add(calendarButton);
        dashboardHeader.add(addButton);

        // HEADER //

        dashboardHeader.setLayout(new FlowLayout());
        dashboardHeader.setBackground(Color.yellow);
        ((FlowLayout)dashboardHeader.getLayout()).setHgap(50);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 0;
        c.ipady = 100;
        dashboardPanel.add(dashboardHeader, c);


        // DASHBOARD CALENDAR //

        calendarPanel.setLayout(new GridBagLayout());
        calendarPanel.setBackground(new Color(200,200,200));
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 1;
        c.ipadx = 600;
        dashboardPanel.add(calendarPanel, c);
        GridBagConstraints cell = new GridBagConstraints();
        for (int i = 0 ; i < 7; i++) {
            JPanel dayCell = new JPanel();
            dayCell.setLayout(new GridLayout(4,1));
            dayCell.setPreferredSize(new Dimension(150, 95));
            dayCell.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            cell.gridx = i;
            cell.gridy = 0;
            calendarPanel.add(dayCell, cell);
            // Add label to the cell //
            JLabel date = new JLabel();
            DateFormat dateFormat = new SimpleDateFormat("EEE dd MMM yyyy");
            Date now = new Date();
            date.setText(dateFormat.format(now.getTime() + ((1000 * 60 * 60 * 24)*i)));
            date.setForeground(new Color(20,20,20));
            JPanel datePane = new JPanel();
            datePane.setBackground(new Color(0, 204, 255));
            datePane.add(date);
            dayCell.add(datePane);
            // Add task to cell //
            for (Task task: Main.tasks) {
                String todayTask = dateFormat.format(task.getDeadline());
                String today = dateFormat.format(now.getTime()+ ((1000 * 60 * 60 * 24)*i));
                if (today.equals(todayTask)) {
                    JPanel taskInCell = new JPanel();
                    taskInCell.setBackground(getColor(task));
                    JLabel name = new JLabel();
                    name.setText(task.getName());
                    name.setForeground(Color.white);
                    taskInCell.add(name);
                    dayCell.add(taskInCell);
                }
            }
        }


        // DASHBOARD CARD //

        cardPanel.setLayout(new FlowLayout());
        cardPanel.setBackground(new Color(200,200,200));
        ((FlowLayout)cardPanel.getLayout()).setHgap(30);
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 2;
        c.ipady = 150;
        dashboardPanel.add(cardPanel, c);

        ArrayList<Task> cardList = new ArrayList<Task>();
        for (int i = 0; i < Main.tasks.size(); i++) {
            if (i >= 4) {
                break;
            }
            cardList.add(Main.tasks.get(i));
        }
        displayCard(cardList);
        // DUE TODAY AND OVERDUE //

        bottomPanel.setLayout(new GridBagLayout());
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 3;
        c.ipady = 200;
        dashboardPanel.add(bottomPanel, c);
        // ADD DUE TODAY //
        JPanel dueToday = new JPanel();
        dueToday.setLayout(new GridLayout(6,1));
        dueToday.setPreferredSize(new Dimension(500,200));
        dueToday.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        bottomPanel.add(dueToday);
        bottomPanel.setBackground(new Color(200,200,200));
        DateFormat dateFormat = new SimpleDateFormat("EEE dd MMM yyyy");
        Date now = new Date();
        String today = dateFormat.format(now.getTime());
        JLabel dueText = new JLabel("Due Today");
        dueText.setForeground(new Color(20,20,20));
        JPanel dueTextPane = new JPanel();
        dueTextPane.add(dueText);
        dueTextPane.setBackground(new Color(0, 204, 255));
        dueToday.add(dueTextPane);
        for (Task task: Main.tasks) {
            String todayTask = dateFormat.format(task.getDeadline());
            if (today.equals(todayTask) && now.getTime() < task.getDeadline().getTime()) {
                JPanel row = new JPanel();
                row.setBackground(getColor(task));
                JLabel taskLabel = new JLabel();
                taskLabel.setForeground(Color.white);
                taskLabel.setText(task.getName());
                row.add(taskLabel);
                dueToday.add(row);
            }
        }

        // ADD OVERDUE //
        JPanel overdue = new JPanel();
        overdue.setLayout(new GridLayout(6,1));
        overdue.setPreferredSize(new Dimension(500,200));
        overdue.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        bottomPanel.add(overdue);
        JLabel overdueText = new JLabel("Overdue");
        overdueText.setForeground(new Color(20,20,20));
        JPanel overdueTextPane = new JPanel();
        overdueTextPane.add(overdueText);
        overdueTextPane.setBackground(new Color(0, 204, 255));

        overdue.add(overdueTextPane);
        for (Task task: Main.tasks) {
            if (now.getTime() > task.getDeadline().getTime()) {
                JPanel row = new JPanel();
                row.setBackground(getColor(task));
                JLabel taskLabel = new JLabel();
                taskLabel.setForeground(Color.white);
                taskLabel.setText(task.getName());
                row.add(taskLabel);
                overdue.add(row);
            }
        }

        // DASHBOARD FRAME //
        dashboardFrame.add(dashboardPanel);
        dashboardFrame.setResizable(false);
        dashboardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dashboardFrame.revalidate();
        dashboardFrame.repaint();
        // SET FULLSCREEN //
        dashboardFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
    String milliToDays(long milli) {
        long minutes =  ((milli / (1000*60)) % 60);
        long hours   =  ((milli / (1000*60*60)) % 24);
        long days =  ((milli / (1000*60*60*24)) % 30);

        return days + "days" + hours + "h" + minutes + "mins";
    }

    void displayCard(ArrayList<Task> cardList) {
        for (Task task: cardList) {
            JPanel card = new JPanel();
            card.setLayout(new BorderLayout());
            card.setPreferredSize(new Dimension(210, 225));
            card.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            // ADD DEADLINE LABEL //

            JPanel deadline = new JPanel();
            deadline.setPreferredSize(new Dimension(190, 20));
            JLabel date = new JLabel();
            DateFormat dateFormat = new SimpleDateFormat("EEE dd MMM yyyy");
            String dateText = dateFormat.format(task.getDeadline());
            date.setText(dateText);
            Date current = new Date();
            long remain = task.getDeadline().getTime() - current.getTime();
            JLabel remaining = new JLabel(milliToDays(remain));
            deadline.add(date);
            deadline.add(remaining);
            card.add(deadline, BorderLayout.NORTH);

            // ADD DESCRIPTION LABEL //

            JPanel descPane = new JPanel();
            descPane.setPreferredSize(new Dimension(140, 185));
            JLabel title = new JLabel("Description:");
            JTextArea desc = new JTextArea();
            desc.setLineWrap(true);
            desc.setWrapStyleWord(true);
            desc.setOpaque(false);
            desc.setEditable(false);
            desc.setText(task.getDescription());
            descPane.add(title);
            descPane.add(desc);
            card.add(descPane, BorderLayout.CENTER);
            // ADD NAME LABEL //
            JPanel namePane = new JPanel();
            namePane.setBackground(getColor(task));
            JLabel name = new JLabel();
            name.setForeground(Color.white);
            name.setText(task.getName());
            namePane.add(name);
            namePane.setPreferredSize(new Dimension(150,30));
            card.add(namePane, BorderLayout.SOUTH);
            cardPanelList.add(card);
        }
        for (JPanel card: cardPanelList) {
            cardPanel.add(card);
        }
    }
    static Color getColor(Task task) {
        Color color;
        if (task.getPriority() == 'A') {
            color = Color.red;
        } else if (task.getPriority() == 'B') {
            color = new Color(255, 102,0);
        } else if (task.getPriority() == 'C') {
            color = new Color(204,204,0);
        } else {
            color = Color.blue;
        }
        return color;
    }
}
