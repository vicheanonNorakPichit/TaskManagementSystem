import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Task {
    // Task Attributes //
    private String name;
    private String description;
    private String state = "toDo";
    private char priority;
    private Date deadline;
    // getter //
    public String getName() {
        
        return name;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Date getDeadline() {
        return deadline;
    }

    public String getDescription() {
        return description;
    }

    public char getPriority() {
        return priority;
    }

    public String getState() {
        return state;
    }
    // setter //

    Task(String name, String description, char priority, String deadline, String word) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
        this.name = name;
        this.deadline = sdf.parse(deadline);
        this.description = description;
        this.priority = priority;
    }
    // Task Function //
    void edit() {

    }
    void delete() {

    }
    static void addTaskTxt()throws Exception{
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== AddTask ===");
        System.out.println("Name: ");
        String name = scanner.nextLine();
		System.out.println("Deadline: ");
		String deadline = scanner.nextLine();
        System.out.println("Description: ");
        String  description = scanner.nextLine();
        System.out.println("Priority: ");
        String priority = scanner.nextLine();
        System.out.println("ID: ");
        int id = scanner.nextInt();
        try {
            FileWriter writer = new FileWriter("addnewtask.txt", true);
            BufferedWriter buffer = new BufferedWriter(writer);
            buffer.append(name + "/" + description + "/" + priority + "/" + deadline + "/" + id + "\n");
            buffer.close();
        } catch (IOException e) {
            System.out.println("Error occurred!");
        }
    }
    // String name, String description, String state, String priority, Date deadline, int taskID
    static void addToList(ArrayList<Task> taskList) {
        try {
            FileReader reader = new FileReader("addnewtask.txt");
            BufferedReader buffer = new BufferedReader(reader);
            String line;
            while ((line = buffer.readLine()) != null) {
                String[] words = line.split("/");
                Task task = new Task(words[0], words[1], words[2].charAt(0), words[3], words[4]);
                taskList.add(task);
            }
        } catch (IOException | ParseException e) {
            System.out.println("Error occurred. Add to linked list");
        }
    }
    static void addTask(ArrayList<Task> taskList) throws Exception {
        addTaskTxt();
        addToList(taskList);
    }

}

