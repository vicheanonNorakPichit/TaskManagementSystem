import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Main {
    // STATIC DECLARATION OF DASHBOARD //

    static ArrayList<Task> tasks = new ArrayList<Task>();
    static ArrayList<Task> todoList = new ArrayList<Task>();
    static ArrayList<Task> noDeadlineList = new ArrayList<Task>();
    static ArrayList<Task> completeList = new ArrayList<Task>();
    static MyFrame run;

    // CARD PANEL DECLARATION //
    public static void main(String[] args) throws Exception {
        Task.addToList(Main.tasks);
        run = new MyFrame();

    }

}